use crate::renderer::GpuCapabilityTier;
use crate::types::{GpuParticle, ParticleUniforms};
use crate::vertex::{InstanceData, InstanceData3D, Vertex, Vertex3D};
use crate::{WGSL_PARTICLES, WGSL_TONEMAP, WGSL_SKINNING};

pub(crate) struct CompiledPipelines {
    pub(crate) pipeline: wgpu::RenderPipeline,
    pub(crate) opaque_pipeline: wgpu::RenderPipeline,
    pub(crate) ui_pipeline: wgpu::RenderPipeline,
    pub(crate) glass_pipeline: wgpu::RenderPipeline,
    pub(crate) background_pipeline: wgpu::RenderPipeline,
    pub(crate) bloom_extract_pipeline: wgpu::RenderPipeline,
    pub(crate) copy_pipeline: wgpu::RenderPipeline,
    pub(crate) composite_pipeline: wgpu::RenderPipeline,
    pub(crate) color_blind_pipeline: wgpu::RenderPipeline,
    pub(crate) volumetric_pipeline: wgpu::RenderPipeline,
    pub(crate) volumetric_bind_group_layout: wgpu::BindGroupLayout,
    pub(crate) volumetric_uniform_buffer: wgpu::Buffer,
    pub(crate) volumetric_depth_sampler: wgpu::Sampler,
    pub(crate) color_blind_bind_group_layout: wgpu::BindGroupLayout,
    pub(crate) color_blind_uniform_buffer: wgpu::Buffer,
    pub(crate) sampler: wgpu::Sampler,
    pub(crate) kawase_down_pipeline: wgpu::RenderPipeline,
    pub(crate) kawase_up_pipeline: wgpu::RenderPipeline,
    pub(crate) kawase_bind_group_layout: wgpu::BindGroupLayout,
    pub(crate) kawase_uniform: wgpu::Buffer,
    pub(crate) kawase_uniform_buffers: Vec<wgpu::Buffer>,
    pub(crate) particle_compute_pipeline: wgpu::ComputePipeline,
    pub(crate) particle_compute_bgl: wgpu::BindGroupLayout,
    pub(crate) particle_buffer: wgpu::Buffer,
    pub(crate) particle_uniform_buffer: wgpu::Buffer,
    pub(crate) particle_render_pipeline: wgpu::RenderPipeline,
    pub(crate) particle_render_bgl: wgpu::BindGroupLayout,
    pub(crate) tonemap_pipeline: wgpu::RenderPipeline,
    // New 3D pipelines
    pub(crate) pbr_pipeline: wgpu::RenderPipeline,
    pub(crate) transparent_pipeline: wgpu::RenderPipeline,
    pub(crate) shadow_pipeline: wgpu::RenderPipeline,
    pub(crate) skinning_compute_pipeline: wgpu::ComputePipeline,
    pub(crate) skinning_bgl0: wgpu::BindGroupLayout,
    pub(crate) skinning_bgl1: wgpu::BindGroupLayout,
    pub(crate) skinning_bgl2: wgpu::BindGroupLayout,
    // Deferred rendering pipelines
    pub(crate) gbuffer_pipeline: wgpu::RenderPipeline,
    pub(crate) deferred_lighting_pipeline: wgpu::RenderPipeline,
    pub(crate) ssao_pipeline: wgpu::RenderPipeline,
    // Deferred bind group layouts
    pub(crate) deferred_bgl: wgpu::BindGroupLayout,
    pub(crate) ssao_bgl: wgpu::BindGroupLayout,
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn compile_render_pipelines(
    device: &wgpu::Device,
    tier: &GpuCapabilityTier,
    format: wgpu::TextureFormat,
    pipeline_cache: Option<&wgpu::PipelineCache>,
    texture_bind_group_layout: &wgpu::BindGroupLayout,
    env_bind_group_layout: &wgpu::BindGroupLayout,
    berserker_bind_group_layout: &wgpu::BindGroupLayout,
    gradient_bind_group_layout: &wgpu::BindGroupLayout,
    pbr_material_bind_group_layout: &wgpu::BindGroupLayout,
    gi_bind_group_layout: &wgpu::BindGroupLayout,
    shader: &wgpu::ShaderModule,
    wgsl_opaque: &str,
    wgsl_glass: &str,
    wgsl_pbr: &str,
    wgsl_shadow: &str,
    queue: &wgpu::Queue,
    msaa_sample_count: u32,
) -> CompiledPipelines {
    // Main 2D pipeline uses groups 0-3 only (max_bind_groups=4 on AMD WebGPU).
    // GI bindings are folded into gradient_bind_group_layout at @group(3) bindings 2,3.
    let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Surtr Main Pipeline Layout"),
        bind_group_layouts: &[
            Some(texture_bind_group_layout),      // group(0): texture array
            Some(env_bind_group_layout),           // group(1): env/blur
            Some(berserker_bind_group_layout),     // group(2): theme/scene/csm
            Some(gradient_bind_group_layout),      // group(3): gradient + GI (folded)
        ],
        immediate_size: 0,
    });

    let post_process_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Muspelheim Post Process Layout"),
        bind_group_layouts: &[
            Some(texture_bind_group_layout),
            Some(env_bind_group_layout),
            Some(berserker_bind_group_layout),
            Some(gradient_bind_group_layout),
        ],
        immediate_size: 0,
    });

    let composite_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Muspelheim Composite Layout"),
        bind_group_layouts: &[
            Some(texture_bind_group_layout),
            Some(env_bind_group_layout),
            Some(berserker_bind_group_layout),
            Some(gradient_bind_group_layout),
        ],
        immediate_size: 0,
    });

    tracing::info!("[Pipelines] Creating Surtr Main Pipeline...");
    let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr Main Pipeline"),
        layout: Some(&pipeline_layout),
        vertex: wgpu::VertexState {
            module: shader,
            entry_point: Some("vs_main"),
            buffers: &[Vertex::desc(), InstanceData::desc()],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: wgpu::TextureFormat::Depth32Float,
            depth_write_enabled: Some(true),
            depth_compare: Some(wgpu::CompareFunction::GreaterEqual),
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState {
            count: msaa_sample_count,
            mask: !0,
            alpha_to_coverage_enabled: false,
        },
        multiview_mask: None,
cache: pipeline_cache,
    });

    let opaque_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Muspelheim Opaque"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(wgsl_opaque)),
    });
    let glass_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Muspelheim Glass"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(wgsl_glass)),
    });

    // `background_pipeline` (AURORA clear) only references @group(2) (theme/scene)
    // via vs_fullscreen/fs_background. The shader module also implicitly declares
    // @group(3) (GI in common.wgsl, gradient in material_opaque.wgsl — but
    // background_pipeline's shader (fs_background/vs_fullscreen) does NOT include
    // material_opaque.wgsl, so it never references group 3). Layout declares only
    // groups 0-3 to stay within WebGPU's max_bind_groups=4 limit. Group 2 is set
    // at runtime; groups 0/1/3 are unused by fs_background.
    let background_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Surtr Background Pipeline Layout"),
        bind_group_layouts: &[
            None,                                // group(0): unused
            None,                                // group(1): unused
            Some(berserker_bind_group_layout),  // group(2): scene/theme uniforms
            None,                                // group(3): unused by fs_background
        ],
        immediate_size: 0,
    });

    let background_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr Background Pipeline"),
        layout: Some(&background_layout),
        vertex: wgpu::VertexState {
            module: shader,
            entry_point: Some("vs_fullscreen"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: shader,
            entry_point: Some("fs_background"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: wgpu::TextureFormat::Depth32Float,
            depth_write_enabled: Some(false),
            depth_compare: Some(wgpu::CompareFunction::Always),
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState {
            count: msaa_sample_count,
            mask: !0,
            alpha_to_coverage_enabled: false,
        },
        multiview_mask: None,
        cache: pipeline_cache,
    });
    tracing::info!(
        "[Pipelines] Surtr Background Pipeline created: label=Surtr Background Pipeline, msaa={}, fmt=Rgba16Float",
        msaa_sample_count,
    );

    let opaque_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Muspelheim Opaque"),
        layout: Some(&pipeline_layout),
        vertex: wgpu::VertexState {
            module: &opaque_shader,
            entry_point: Some("vs_main"),
            buffers: &[Vertex::desc(), InstanceData::desc()],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &opaque_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: wgpu::TextureFormat::Depth32Float,
            depth_write_enabled: Some(true),
            depth_compare: Some(wgpu::CompareFunction::GreaterEqual),
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState {
            count: msaa_sample_count,
            mask: !0,
            alpha_to_coverage_enabled: false,
        },
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let ui_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Muspelheim UI"),
        layout: Some(&pipeline_layout),
        vertex: wgpu::VertexState {
            module: &opaque_shader,
            entry_point: Some("vs_main"),
            buffers: &[Vertex::desc(), InstanceData::desc()],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &opaque_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState {
            count: 1,
            mask: !0,
            alpha_to_coverage_enabled: false,
        },
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let glass_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Muspelheim Glass"),
        layout: Some(&pipeline_layout),
        vertex: wgpu::VertexState {
            module: &opaque_shader,
            entry_point: Some("vs_main"),
            buffers: &[Vertex::desc(), InstanceData::desc()],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &glass_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState {
            count: 1,
            mask: !0,
            alpha_to_coverage_enabled: false,
        },
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let pbr_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Surtr PBR Pipeline Layout"),
        bind_group_layouts: &[
            Some(texture_bind_group_layout),
            Some(env_bind_group_layout),
            Some(berserker_bind_group_layout),
            Some(pbr_material_bind_group_layout), // GI is folded into this layout at @group(3) bindings 2,3
        ],
        immediate_size: 0,
    });

    let pbr_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Surtr PBR Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(wgsl_pbr)),
    });

    let pbr_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr PBR"),
        layout: Some(&pbr_layout),
        vertex: wgpu::VertexState {
            module: &pbr_shader,
            entry_point: Some("vs_main_3d"),
            buffers: &[Vertex3D::desc(), InstanceData3D::desc()],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &pbr_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: wgpu::TextureFormat::Depth32Float,
            depth_write_enabled: Some(true),
            depth_compare: Some(wgpu::CompareFunction::GreaterEqual),
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let transparent_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr Transparent PBR"),
        layout: Some(&pbr_layout),
        vertex: wgpu::VertexState {
            module: &pbr_shader,
            entry_point: Some("vs_main_3d"),
            buffers: &[Vertex3D::desc(), InstanceData3D::desc()],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &pbr_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: wgpu::TextureFormat::Depth32Float,
            depth_write_enabled: Some(false),
            depth_compare: Some(wgpu::CompareFunction::GreaterEqual),
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    // Shadow pipeline for cascaded shadow map rendering (depth-only)
    let shadow_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Surtr Shadow Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(wgsl_shadow)),
    });

    let shadow_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr Shadow Map"),
        layout: Some(&pipeline_layout),
        vertex: wgpu::VertexState {
            module: &shadow_shader,
            entry_point: Some("vs_shadow"),
            buffers: &[Vertex3D::desc(), InstanceData3D::desc()],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: None, // Depth-only pass
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: wgpu::TextureFormat::Depth32Float,
            depth_write_enabled: Some(true),
            depth_compare: Some(wgpu::CompareFunction::Less),
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let bloom_extract_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Muspelheim Bloom Extract"),
        layout: Some(&post_process_layout),
        vertex: wgpu::VertexState {
            module: shader,
            entry_point: Some("vs_fullscreen"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: shader,
            entry_point: Some("fs_bloom_extract"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float, // HDR for bloom
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let copy_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Muspelheim Copy"),
        layout: Some(&post_process_layout),
        vertex: wgpu::VertexState {
            module: shader,
            entry_point: Some("vs_fullscreen"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: shader,
            entry_point: Some("fs_copy"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float, // HDR for bloom chains
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let kawase_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Kawase Blur Pyramid"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(include_str!(
            "../shaders/blur_pyramid.wgsl"
        ))),
    });

    let kawase_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("Kawase Blur BGL"),
        entries: &[
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: wgpu::BufferSize::new(32),
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 1,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Float { filterable: true },
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 2,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
        ],
    });

    let kawase_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Kawase Pipeline Layout"),
        bind_group_layouts: &[Some(&kawase_bgl)],
        immediate_size: 0,
    });

    let kawase_down_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Kawase Downsample"),
        layout: Some(&kawase_layout),
        vertex: wgpu::VertexState {
            module: &kawase_shader,
            entry_point: Some("vs_blur"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &kawase_shader,
            entry_point: Some("fs_kawase_down"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float, // HDR for bloom
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let kawase_up_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Kawase Upsample"),
        layout: Some(&kawase_layout),
        vertex: wgpu::VertexState {
            module: &kawase_shader,
            entry_point: Some("vs_blur"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &kawase_shader,
            entry_point: Some("fs_kawase_up"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float, // HDR for bloom
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let composite_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Muspelheim Composite"),
        layout: Some(&composite_layout),
        vertex: wgpu::VertexState {
            module: shader,
            entry_point: Some("vs_fullscreen"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: shader,
            entry_point: Some("fs_composite"),
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: None, // No blend - just tonemap and output
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let color_blind_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("Color Blind Bind Group Layout"),
        entries: &[
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Float { filterable: true },
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 1,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 2,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: wgpu::BufferSize::new(std::mem::size_of::<
                        crate::color_blindness::ColorBlindUniforms,
                    >() as u64),
                },
                count: None,
            },
        ],
    });

    let color_blind_pipeline_layout =
        device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Color Blind Pipeline Layout"),
            bind_group_layouts: &[Some(&color_blind_bgl)],
            immediate_size: 0,
        });

    let color_blind_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Surtr Color Blind Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(
            crate::color_blindness::shader_source(),
        )),
    });

    let color_blind_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr Color Blindness"),
        layout: Some(&color_blind_pipeline_layout),
        vertex: wgpu::VertexState {
            module: &color_blind_shader,
            entry_point: Some("fs_main_vs"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &color_blind_shader,
            entry_point: Some("fs_color_blind"),
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let volumetric_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Surtr Volumetric Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(include_str!(
            "../shaders/volumetric.wgsl"
        ))),
    });

    let dummy_bgl =
        device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Dummy BGL"),
            entries: &[], // Empty layout
        });

    let volumetric_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Surtr Volumetric Layout"),
        bind_group_layouts: &[Some(&dummy_bgl)], // Keep layout for compatibility
        immediate_size: 0,
    });

    let volumetric_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr Volumetric Raymarching"),
        layout: Some(&volumetric_layout),
        vertex: wgpu::VertexState {
            module: &volumetric_shader,
            entry_point: Some("vs_fullscreen"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &volumetric_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rgba16Float,
                // Additive blend: src + dst. The placeholder shader returns
                // transparent black (0,0,0,0), contributing nothing, so when
                // volumetric is enabled but no raymarch content is produced
                // the scene is preserved as-is. A real raymarch shader can
                // later output glow colors that will add onto the scene.
                blend: Some(wgpu::BlendState {
                    color: wgpu::BlendComponent {
                        src_factor: wgpu::BlendFactor::One,
                        dst_factor: wgpu::BlendFactor::One,
                        operation: wgpu::BlendOperation::Add,
                    },
                    alpha: wgpu::BlendComponent {
                        src_factor: wgpu::BlendFactor::One,
                        dst_factor: wgpu::BlendFactor::One,
                        operation: wgpu::BlendOperation::Add,
                    },
                }),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let tonemap_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Surtr ToneMap Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(WGSL_TONEMAP)),
    });

    let tonemap_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("ToneMap Bind Group Layout"),
        entries: &[
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: wgpu::BufferSize::new(std::mem::size_of::<[f32; 4]>() as u64),
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 1,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Float { filterable: true },
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 2,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
        ],
    });

    let tonemap_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Surtr ToneMap Layout"),
        bind_group_layouts: &[Some(&tonemap_bgl)],
        immediate_size: 0,
    });

    let tonemap_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr ToneMapping"),
        layout: Some(&tonemap_layout),
        vertex: wgpu::VertexState {
            module: &tonemap_shader,
            entry_point: Some("vs_fullscreen"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &tonemap_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let color_blind_uniform_buffer = device.create_buffer(&wgpu::BufferDescriptor {
        label: Some("Color Blind Uniforms"),
        size: std::mem::size_of::<crate::color_blindness::ColorBlindUniforms>() as u64,
        usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        mapped_at_creation: false,
    });

    let volumetric_uniform_buffer = device.create_buffer(&wgpu::BufferDescriptor {
        label: Some("Volumetric Uniforms"),
        size: std::mem::size_of::<[f32; 32]>() as u64,
        usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        mapped_at_creation: false,
    });

    let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
        address_mode_u: wgpu::AddressMode::ClampToEdge,
        address_mode_v: wgpu::AddressMode::ClampToEdge,
        mag_filter: wgpu::FilterMode::Linear,
        min_filter: wgpu::FilterMode::Linear,
        ..Default::default()
    });

    let volumetric_depth_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
        address_mode_u: wgpu::AddressMode::ClampToEdge,
        address_mode_v: wgpu::AddressMode::ClampToEdge,
        mag_filter: wgpu::FilterMode::Linear,
        min_filter: wgpu::FilterMode::Linear,
        compare: Some(wgpu::CompareFunction::Less),
        ..Default::default()
    });

    let particle_compute_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("Particle Compute BGL"),
        entries: &[
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::COMPUTE,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Storage { read_only: false },
                    has_dynamic_offset: false,
                    min_binding_size: wgpu::BufferSize::new(
                        (tier.max_particles * std::mem::size_of::<GpuParticle>()) as u64,
                    ),
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 1,
                visibility: wgpu::ShaderStages::COMPUTE,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: wgpu::BufferSize::new(
                        std::mem::size_of::<ParticleUniforms>() as u64,
                    ),
                },
                count: None,
            },
        ],
    });

    let particle_compute_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Particle Compute Layout"),
        bind_group_layouts: &[Some(&particle_compute_bgl)],
        immediate_size: 0,
    });

    let particle_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Particles Compute Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(WGSL_PARTICLES)),
    });

    let particle_compute_pipeline =
        device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
            label: Some("Particle Compute Pipeline"),
            layout: Some(&particle_compute_layout),
            module: &particle_shader,
            entry_point: Some("cs_main"),
            compilation_options: wgpu::PipelineCompilationOptions::default(),
            cache: pipeline_cache,
        });

    let particle_buffer = device.create_buffer(&wgpu::BufferDescriptor {
        label: Some("Particle Storage Buffer"),
        size: (tier.max_particles * std::mem::size_of::<GpuParticle>()) as u64,
        usage: wgpu::BufferUsages::STORAGE
            | wgpu::BufferUsages::COPY_DST
            | wgpu::BufferUsages::VERTEX,
        mapped_at_creation: false,
    });

    let particle_uniform_buffer = device.create_buffer(&wgpu::BufferDescriptor {
        label: Some("Particle Uniform Buffer"),
        size: std::mem::size_of::<ParticleUniforms>() as u64,
        usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        mapped_at_creation: false,
    });

    let particle_render_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("Particle Render BGL"),
        entries: &[wgpu::BindGroupLayoutEntry {
            binding: 0,
            visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Buffer {
                ty: wgpu::BufferBindingType::Storage { read_only: true },
                has_dynamic_offset: false,
                min_binding_size: wgpu::BufferSize::new(
                    (tier.max_particles * std::mem::size_of::<GpuParticle>()) as u64,
                ),
            },
            count: None,
        }],
    });

    let particle_render_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Particle Render Layout"),
        bind_group_layouts: &[Some(&particle_render_bgl)],
        immediate_size: 0,
    });

    let particle_render_wgsl = "
struct Particle {
    pos_vel: vec4<f32>,
    color_life: vec4<f32>,
};
struct ParticleArray {
    particles: array<Particle>,
};
@group(0) @binding(0) var<storage, read> particles: ParticleArray;

struct VsOut {
    @builtin(position) pos: vec4<f32>,
    @location(0) color: vec4<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vi: u32) -> VsOut {
    var out: VsOut;
    let p = particles.particles[vi];
    let life = p.color_life.w;
    if (life <= 0.0) {
        out.pos = vec4<f32>(0.0, 0.0, 2.0, 1.0);
        out.color = vec4<f32>(0.0);
    } else {
        let alpha = min(life, 1.0);
        out.pos = vec4<f32>(p.pos_vel.xy, 0.0, 1.0);
        out.color = vec4<f32>(p.color_life.xyz, alpha);
    }
    return out;
}

@fragment
fn fs_main(@location(0) color: vec4<f32>) -> @location(0) vec4<f32> {
    return color;
}
";

    let particle_render_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Particle Render Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(particle_render_wgsl)),
    });

    let particle_render_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Particle Render Pipeline"),
        layout: Some(&particle_render_layout),
        vertex: wgpu::VertexState {
            module: &particle_render_shader,
            entry_point: Some("vs_main"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &particle_render_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: Some(wgpu::BlendState {
                    color: wgpu::BlendComponent {
                        src_factor: wgpu::BlendFactor::SrcAlpha,
                        dst_factor: wgpu::BlendFactor::One,
                        operation: wgpu::BlendOperation::Add,
                    },
                    alpha: wgpu::BlendComponent {
                        src_factor: wgpu::BlendFactor::One,
                        dst_factor: wgpu::BlendFactor::One,
                        operation: wgpu::BlendOperation::Add,
                    },
                }),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState {
            topology: wgpu::PrimitiveTopology::PointList,
            ..Default::default()
        },
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    let kawase_uniform = device.create_buffer(&wgpu::BufferDescriptor {
        label: Some("Kawase Persistent Uniform"),
        size: 32,
        usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        mapped_at_creation: false,
    });

    let kawase_uniform_buffers: Vec<wgpu::Buffer> = (0..16)
        .map(|i| {
            device.create_buffer(&wgpu::BufferDescriptor {
                label: Some(&format!("Kawase Persistent Uniform {}", i)),
                size: 32,
                usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            })
        })
        .collect();

    let skinning_bgl0 = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        entries: &[
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::COMPUTE,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Storage { read_only: true },
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 1,
                visibility: wgpu::ShaderStages::COMPUTE,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Storage { read_only: false },
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            },
        ],
        label: Some("Skinning Geometry Bind Group Layout"),
    });

    let skinning_bgl1 = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        entries: &[
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::COMPUTE,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Storage { read_only: true },
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            },
        ],
        label: Some("Skinning Joint Bind Group Layout"),
    });

    let skinning_bgl2 = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        entries: &[
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::COMPUTE,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Storage { read_only: true },
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 1,
                visibility: wgpu::ShaderStages::COMPUTE,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            },
        ],
        label: Some("Skinning Morph Bind Group Layout"),
    });

    let skinning_pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Skinning Compute Pipeline Layout"),
        bind_group_layouts: &[Some(&skinning_bgl0), Some(&skinning_bgl1), Some(&skinning_bgl2)],
        immediate_size: 0,
    });

    let skinning_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Skinning Compute Shader Module"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(WGSL_SKINNING)),
    });

    let skinning_compute_pipeline = device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
        label: Some("Skinning Compute Pipeline"),
        layout: Some(&skinning_pipeline_layout),
        module: &skinning_shader,
        entry_point: Some("main"),
        compilation_options: wgpu::PipelineCompilationOptions::default(),
        cache: pipeline_cache,
    });

    // Deferred rendering pipelines
    let deferred_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Surtr Deferred Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(include_str!(
            "../shaders/deferred_lighting.wgsl"
        ))),
    });

    let deferred_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("Deferred Lighting BGL"),
        entries: &[
            // binding 0: albedo texture
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Float { filterable: true },
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            // binding 1: albedo sampler
            wgpu::BindGroupLayoutEntry {
                binding: 1,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
            // binding 2: normal texture
            wgpu::BindGroupLayoutEntry {
                binding: 2,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Float { filterable: true },
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            // binding 3: normal sampler
            wgpu::BindGroupLayoutEntry {
                binding: 3,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
            // binding 4: depth texture
            wgpu::BindGroupLayoutEntry {
                binding: 4,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Depth,
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            // binding 5: depth sampler
            wgpu::BindGroupLayoutEntry {
                binding: 5,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
            // binding 6: ssao texture
            wgpu::BindGroupLayoutEntry {
                binding: 6,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Float { filterable: true },
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            // binding 7: ssao sampler
            wgpu::BindGroupLayoutEntry {
                binding: 7,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
        ],
    });

let deferred_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Surtr Deferred Layout"),
        bind_group_layouts: &[
            Some(berserker_bind_group_layout), // Group 0: Scene uniforms
            Some(&deferred_bgl),               // Group 1: G-buffer textures
            Some(gi_bind_group_layout),        // Group 2: GI uniforms (probe coefficients)
        ],
        immediate_size: 0,
    });

    let deferred_lighting_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr Deferred Lighting"),
        layout: Some(&deferred_layout),
        vertex: wgpu::VertexState {
            module: &deferred_shader,
            entry_point: Some("vs_fullscreen"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &deferred_shader,
            entry_point: Some("fs_deferred_resolve"),
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    // G-Buffer pipeline (vertex shader renders to 3 MRTs).
// Uses wgsl_pbr (= WGSL_COMMON + WGSL_MATERIAL_PBR + ...) instead of include_str!
// on material_pbr.wgsl directly, because the raw file references scene/gi/csm
// bindings that are declared in common.wgsl — only the concatenated version
// has those declarations in scope.
let gbuffer_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
    label: Some("Surtr G-Buffer Shader"),
    source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(wgsl_pbr)),
});

    let gbuffer_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr G-Buffer"),
        layout: Some(&pbr_layout),
        vertex: wgpu::VertexState {
            module: &gbuffer_shader,
            entry_point: Some("vs_main_3d"),
            buffers: &[Vertex3D::desc(), InstanceData3D::desc()],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &gbuffer_shader,
            entry_point: Some("fs_gbuffer"),
            targets: &[
                Some(wgpu::ColorTargetState {
                    format: wgpu::TextureFormat::Rgba16Float,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                }),
                Some(wgpu::ColorTargetState {
                    format: wgpu::TextureFormat::Rgba16Float,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                }),
                Some(wgpu::ColorTargetState {
                    format: wgpu::TextureFormat::Rgba16Float,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                }),
            ],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: Some(wgpu::DepthStencilState {
            format: wgpu::TextureFormat::Depth32Float,
            depth_write_enabled: Some(true),
            depth_compare: Some(wgpu::CompareFunction::Less),
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    // SSAO pipeline
    let ssao_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("Surtr SSAO Shader"),
        source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(include_str!(
            "../shaders/ssao.wgsl"
        ))),
    });

    let ssao_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("SSAO BGL"),
        entries: &[
            wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Depth,
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 1,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 2,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Float { filterable: true },
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 3,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                count: None,
            },
        ],
    });

    let ssao_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("Surtr SSAO Layout"),
        bind_group_layouts: &[Some(berserker_bind_group_layout), Some(&ssao_bgl)],
        immediate_size: 0,
    });

    let ssao_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("Surtr SSAO"),
        layout: Some(&ssao_layout),
        vertex: wgpu::VertexState {
            module: &ssao_shader,
            entry_point: Some("vs_fullscreen"),
            buffers: &[],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &ssao_shader,
            entry_point: Some("fs_main"),
            targets: &[Some(wgpu::ColorTargetState {
                format: wgpu::TextureFormat::Rg16Float,
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: wgpu::PipelineCompilationOptions::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview_mask: None,
        cache: pipeline_cache,
    });

    CompiledPipelines {
        pipeline,
        opaque_pipeline,
        ui_pipeline,
        glass_pipeline,
        background_pipeline,
        bloom_extract_pipeline,
        copy_pipeline,
        composite_pipeline,
        color_blind_pipeline,
        volumetric_pipeline,
        volumetric_bind_group_layout: dummy_bgl,
        volumetric_uniform_buffer,
        volumetric_depth_sampler,
        color_blind_bind_group_layout: color_blind_bgl,
        color_blind_uniform_buffer,
        sampler,
        kawase_down_pipeline,
        kawase_up_pipeline,
        kawase_bind_group_layout: kawase_bgl,
        kawase_uniform,
        kawase_uniform_buffers,
        particle_compute_pipeline,
        particle_compute_bgl,
        particle_buffer,
        particle_uniform_buffer,
        particle_render_pipeline,
        particle_render_bgl,
        tonemap_pipeline,
        pbr_pipeline,
        transparent_pipeline,
        shadow_pipeline,
        skinning_compute_pipeline,
        skinning_bgl0,
        skinning_bgl1,
        skinning_bgl2,
        gbuffer_pipeline,
        deferred_lighting_pipeline,
        ssao_pipeline,
        deferred_bgl,
        ssao_bgl,
    }
}
