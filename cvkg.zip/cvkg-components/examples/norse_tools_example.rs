// CVKG Norse Tools Example
// Demonstrates Phase 5 components: Bragi Creative, Hlin Accessibility, Eir Motion, Tyr Security
//
// Run with: cargo run --example norse_tools_example

use cvkg_components::{
    Animated, CreativeTools, Easing, HlinAccessibility, PermissionLevel, Text, Transition,
    TyrSecurity,
};
use cvkg_core::AriaRole;

fn main() {
    println!("CVKG Norse Tools Example");
    println!("========================\n");

    // Bragi Creative - Creative suite
    let bragi = CreativeTools::new()
        .rich_text("main_doc", "Welcome to CVKG")
        .markdown("readme", "# Header\nContent here")
        .svg("logo")
        .active("main_doc");

    println!("Bragi Creative: {} components", bragi.components.len());

    // Hlin Accessibility - Accessibility infrastructure
    let hlin = HlinAccessibility::new()
        .node("btn_1", AriaRole::Button, "Submit")
        .node("nav_1", AriaRole::Navigation, "Main Menu")
        .node("main_1", AriaRole::Main, "Content Area")
        .high_contrast(true)
        .reduced_motion(true);

    println!("Hlin Accessibility: {} nodes", hlin.tree.len());

    // Animated - Consolidated animation component
    let anim = Animated::new(Text::new("Animated Text"))
        .transition(Transition::Fade)
        .easing(Easing::EaseOut)
        .duration(0.5);

    println!("Animated: duration = {}s", anim.duration);

    // Tyr Security - Security system
    let tyr = TyrSecurity::new()
        .role("viewer", PermissionLevel::User, vec!["read", "comment"])
        .role(
            "editor",
            PermissionLevel::Admin,
            vec!["read", "write", "delete"],
        )
        .audit("alice", "edit_document", "doc_123", true)
        .audit("bob", "delete_file", "file_456", false)
        .session("sess_abc", "workspace_1", 24.0);

    println!(
        "Tyr Security: {} roles, {} audit entries",
        tyr.roles.len(),
        tyr.audit_log.len()
    );

    println!("\n=== Norse Tools Components Created Successfully ===");
}
